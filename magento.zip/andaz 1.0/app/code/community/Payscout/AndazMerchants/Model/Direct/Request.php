<?php
/**
 * Payscout Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 *
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to alex@payscout.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * You can edit or add to this file if you wish to upgrade Magento to newer
 * versions in the future.
 *
 * =================================================================
 *                 MAGENTO EDITION USAGE NOTICE
 * =================================================================
 * This package designed for Magento COMMUNITY edition version 1.5.0.0 to all upper version.
 * Payscout Inc does not guarantee correct work of this extension
 * on any other Magento edition except Magento COMMUNITY edition.
 * Payscout Inc does not provide extension support in case of
 * incorrect edition usage.
 * =================================================================
 *
 * @category   Payscout
 * @package    AndazMerchants
 * @copyright  Copyright (c) 2017 Payscout Inc. (http://www.payscout.com)
 * @license    http://www.payscout.com
 */

class Payscout_AndazMerchants_Model_Direct_Request extends Varien_Object
{
   
}