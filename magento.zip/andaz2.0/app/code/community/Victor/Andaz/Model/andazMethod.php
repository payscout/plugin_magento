<?php

/**
 * Payscout Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 *
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to alex@payscout.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * You can edit or add to this file if you wish to upgrade Magento to newer
 * versions in the future.
 *
 * =================================================================
 *                 MAGENTO EDITION USAGE NOTICE
 * =================================================================
 * This package designed for Magento COMMUNITY edition version 1.5.0.0 to all upper version.
 * Posixtech Ltd. does not guarantee correct work of this extension
 * on any other Magento edition except Magento COMMUNITY edition.
 * Posixtech Ltd. does not provide extension support in case of
 * incorrect edition usage.
 * =================================================================
 *
 * @category   Payscout
 * @package    IncMerchants
 * @copyright  Copyright (c) 2015 Payscout Inc. (http://www.payscout.com)
 * @license    http://www.payscout.com
 */
 
class Victor_Andaz_Model_AndazMethod extends Mage_Payment_Model_Method_Cc
{

    protected $_code = 'andaz'; //unique internal payment method identifier
    protected $_isGateway = true; //Is this payment method a gateway (online auth/charge) ?
    protected $_canAuthorize = true; //Can authorize online?
    protected $_canCapture = true; //Can capture funds online?
    protected $_canCapturePartial = false; //Can capture partial amounts online?
    protected $_canRefund = true; //Can refund online?
    protected $_canRefundInvoicePartial = true; //Can refund invoices partially?
    protected $_canVoid = true; //Can void transactions online?
    protected $_canUseInternal = true; //Can use this payment method in administration panel?
    protected $_canUseCheckout = true; //Can show this payment method as an option on checkout payment page?
    protected $_canUseForMultishipping = false; //Is this payment method suitable for multi-shipping checkout?
    protected $_isInitializeNeeded = false;
    protected $_canFetchTransactionInfo = false;
    protected $_canReviewPayment = false;
    protected $_canCreateBillingAgreement = false;
    protected $_canManageRecurringProfiles = false;
    protected $_canSaveCc = false; //Can save credit card information for future processing?
   
	protected $_formBlockType = 'andaz/direct_form_cc';
    protected $_infoBlockType = 'andaz/direct_info_cc';
    /**
     * Fields that should be replaced in debug with '***'
     *
     * @var array
     */
    protected $_debugReplacePrivateDataKeys = array('clientId', 'clientUsername', 'clientPassword', 'clientToken');

    /**
     * Validate payment method information object
     *
     * @param   Mage_Payment_Model_Info $info
     * @return  Mage_Payment_Model_Abstract
     */
    public function validate()
    {
        $info = $this->getInfoInstance();
        $order_amount = 0;
        if ($info instanceof Mage_Sales_Model_Quote_Payment) {
            $order_amount = (double) $info->getQuote()->getBaseGrandTotal();
        } elseif ($info instanceof Mage_Sales_Model_Order_Payment) {
            $order_amount = (double) $info->getOrder()->getQuoteBaseGrandTotal();
        }

        $order_min = $this->getConfigData('min_order_total');
        $order_max = $this->getConfigData('max_order_total');
        if (!empty($order_max) && (double) $order_max < $order_amount) {
            Mage::throwException("Order amount greater than permissible Maximum order amount.");
        }
        if (!empty($order_min) && (double) $order_min > $order_amount) {
            Mage::throwException("Order amount less than required Minimum order amount.");
        }
        /*
         * calling parent validate function
         */
        parent::validate();
    }

    /**
     * Send authorize request to gateway
     *
     * @param Varien_Object $payment
     * @param decimal $amount
     * @return Mage_Paygate_Model_Authorizenet
     * @throws Mage_Core_Exception
     */
    public function authorize(Varien_Object $payment, $amount)
    {
        if ($amount <= 0) {
            Mage::throwException(Mage::helper('andaz')->__('Invalid amount for transaction.'));
        }
        $payment->setAmount($amount);
        $data = $this->_prepareData();
        
		$dob = date('Ymd',strtotime(date("Ymd", mktime()) . " - 10 year"));
		$ssn = ''; 
		if(isset($_POST['payment']) && $_POST['payment']['dob']!= "")
		{
			$dob = date('Ymd', strtotime($_POST['payment']['dob']));
		}
		
		if(isset($_POST['payment']) && $_POST['payment']['ssn']!= "")
		{
			$ssn = substr($_POST['payment']['ssn'], -4);
		}

        $payment->setAmount($amount);
        $data = $this->_prepareData(); 
		$post_data = '';
		$order = $payment->getOrder();
        if (!empty($order)) {
            $BillingAddress = $order->getBillingAddress();
		
		
		$post_data .= "client_id=" . urlencode($data['clientId']) . "&";
		$post_data .= "client_username=" . urlencode($data['clientUsername']) . "&";
		$post_data .= "client_password=" . urlencode($data['clientPassword']) . "&";
		$post_data .= "client_token=" . urlencode($data['clientToken']) . "&";
		$post_data .= "billing_date_of_birth=" . urlencode($dob) . "&";
		$post_data .= "billing_social_security_number=" . urlencode($ssn) . "&";
		$post_data .= "account_number=" . urlencode($payment->getCcNumber()) . "&";
		$post_data .= "expiration_month=" . urlencode($payment->getCcExpMonth()) . "&";
		$post_data .= "expiration_year=" . urlencode($payment->getCcExpYear()) . "&";
		$post_data .= "cvv2=" . urlencode($payment->getCcCid()) . "&";
		$post_data .= "initial_amount=" . urlencode($payment->getAmount()) . "&";
		$post_data .= "processing_type=debit" . "&";
		$post_data .= "initial_interval=0" . "&";
		$post_data .= "mode=undefined" . "&";		      
        $post_data .= "ip_address=104.158.146.75&"; //. urlencode($request->getIpaddress()) . "&";
        $post_data .= "pass_through=" . urlencode($order->getId()) . "&";
        $post_data .= "domain=http://madisonjamesresearchchems.com" . "&";
		
		// Billing Information
        $post_data .= "billing_first_name=" . urlencode($BillingAddress->getFirstname()) . "&";
        $post_data .= "billing_last_name=" . urlencode($BillingAddress->getLastname()) . "&";       
        $post_data .= "billing_address_line_1=" . urlencode($BillingAddress->getStreet(1)) . "&";
        //$query .= "billing_address_line_2=" . urlencode($request->getBillingAddress2()) . "&";
        $post_data .= "billing_city=" . urlencode($BillingAddress->getCity()) . "&";
        $post_data .= "billing_state=" . urlencode($BillingAddress->getRegion()) . "&";
        $post_data .= "billing_postal_code=" . urlencode($BillingAddress->getPostcode()) . "&";
        $post_data .= "billing_country=" . urlencode($BillingAddress->getCountry()) . "&";
        $post_data .= "billing_phone_number=" . urlencode($BillingAddress->getTelephone()) . "&";       
        $post_data .= "billing_email_address=" . urlencode($order->getCustomerEmail());
       
		}
        // Shipping Information
		
		$ShippingAddress = $order->getShippingAddress();
        if (!empty($shipping))
		{
				$post_data .= "shipping_first_name=" . urlencode($ShippingAddress->getFirstname()) . "&";
				$post_data .= "shipping_last_name=" . urlencode($ShippingAddress->getLastname()) . "&";       
				$post_data .= "shipping_address_line_1=" . urlencode($ShippingAddress->getStreet(1)) . "&";				
				$post_data .= "shipping_city=" . urlencode($ShippingAddress->getCity()) . "&";
				$post_data .= "shipping_state=" . urlencode($ShippingAddress->getRegion()) . "&";
				$post_data .= "shipping_postal_code=" . urlencode($ShippingAddress->getPostcode()) . "&";
				$post_data .= "shipping_country=" . urlencode($ShippingAddress->getCountry()) . "&";				
		}		
       
        $result = $this->_postRequest($post_data);

        if (is_array($result) && count($result) > 0) {
			
			if (array_key_exists("status", $result)) {
                if ($result["status"] == "test-approved" || $result["status"] = "approved") {
					
					$payment->setStatus(self::STATUS_APPROVED);
                    $payment->setLastTransId((string) $result["transaction_id"]);
                    $payment->setTransactionTag((string) $result["original_transaction_id"]);                   
                    $payment->setTransactionId((string) $result["transaction_id"]);
                  
                    return $this;
                }else {
                    $payment->setStatus(self::STATUS_ERROR);
                    Mage::throwException("Gateway error : {" . (string) $result["message"] . "}");
                }
            } else {
                Mage::throwException("No approval found");
            }
        } else {
            Mage::throwException("No response found");
        }
    }

    public function capture(Varien_Object $payment, $amount)
    {
        if ($amount <= 0) {
            Mage::throwException(Mage::helper('linkpoint')->__('Invalid amount for transaction.'));
        }

        if ($payment->getTransactionTag() != '' && Mage::app()->getStore()->isAdmin()) {
            return $this->authorizePayment($payment, number_format($amount, 2, '.', ''));
        }

		$dob = date('Ymd',strtotime(date("Ymd", mktime()) . " - 10 year"));
		$ssn = ''; 
		if(isset($_POST['payment']) && $_POST['payment']['dob']!= "")
		{
			$dob = date('Ymd', strtotime($_POST['payment']['dob']));
		}
		
		if(isset($_POST['payment']) && $_POST['payment']['ssn']!= "")
		{
			$ssn = substr($_POST['payment']['ssn'], -4);
		}

        $payment->setAmount($amount);
        $data = $this->_prepareData(); 
		$post_data = '';
		$order = $payment->getOrder();
        if (!empty($order)) {
            $BillingAddress = $order->getBillingAddress();
		
		
		$post_data .= "client_id=" . urlencode($data['clientId']) . "&";
		$post_data .= "client_username=" . urlencode($data['clientUsername']) . "&";
		$post_data .= "client_password=" . urlencode($data['clientPassword']) . "&";
		$post_data .= "client_token=" . urlencode($data['clientToken']) . "&";
		$post_data .= "billing_date_of_birth=" . urlencode($dob) . "&";
		$post_data .= "billing_social_security_number=" . urlencode($ssn) . "&";
		$post_data .= "account_number=" . urlencode($payment->getCcNumber()) . "&";
		$post_data .= "expiration_month=" . urlencode($payment->getCcExpMonth()) . "&";
		$post_data .= "expiration_year=" . urlencode($payment->getCcExpYear()) . "&";
		$post_data .= "cvv2=" . urlencode($payment->getCcCid()) . "&";
		$post_data .= "initial_amount=" . urlencode($payment->getAmount()) . "&";
		$post_data .= "processing_type=debit" . "&";
		$post_data .= "initial_interval=0" . "&";
		$post_data .= "mode=undefined" . "&";		      
        $post_data .= "ip_address=104.158.146.75&"; //. urlencode($request->getIpaddress()) . "&";
        $post_data .= "pass_through=" . urlencode($order->getId()) . "&";
        $post_data .= "domain=http://madisonjamesresearchchems.com" . "&";
		
		// Billing Information
        $post_data .= "billing_first_name=" . urlencode($BillingAddress->getFirstname()) . "&";
        $post_data .= "billing_last_name=" . urlencode($BillingAddress->getLastname()) . "&";       
        $post_data .= "billing_address_line_1=" . urlencode($BillingAddress->getStreet(1)) . "&";
        //$query .= "billing_address_line_2=" . urlencode($request->getBillingAddress2()) . "&";
        $post_data .= "billing_city=" . urlencode($BillingAddress->getCity()) . "&";
        $post_data .= "billing_state=" . urlencode($BillingAddress->getRegion()) . "&";
        $post_data .= "billing_postal_code=" . urlencode($BillingAddress->getPostcode()) . "&";
        $post_data .= "billing_country=" . urlencode($BillingAddress->getCountry()) . "&";
        $post_data .= "billing_phone_number=" . urlencode($BillingAddress->getTelephone()) . "&";       
        $post_data .= "billing_email_address=" . urlencode($order->getCustomerEmail());
       
		}
        // Shipping Information
		
		$ShippingAddress = $order->getShippingAddress();
        if (!empty($shipping))
		{
				$post_data .= "shipping_first_name=" . urlencode($ShippingAddress->getFirstname()) . "&";
				$post_data .= "shipping_last_name=" . urlencode($ShippingAddress->getLastname()) . "&";       
				$post_data .= "shipping_address_line_1=" . urlencode($ShippingAddress->getStreet(1)) . "&";				
				$post_data .= "shipping_city=" . urlencode($ShippingAddress->getCity()) . "&";
				$post_data .= "shipping_state=" . urlencode($ShippingAddress->getRegion()) . "&";
				$post_data .= "shipping_postal_code=" . urlencode($ShippingAddress->getPostcode()) . "&";
				$post_data .= "shipping_country=" . urlencode($ShippingAddress->getCountry()) . "&";				
		}
		
		
		
        $result = $this->_postRequest($post_data);

        if (is_array($result) && count($result) > 0) {
						
			
            if (array_key_exists("status", $result)) {
                if ($result["status"] == "test-approved" || $result["status"] = "approved") {
					
					$payment->setStatus(self::STATUS_APPROVED);
                    $payment->setLastTransId((string) $result["transaction_id"]);
                    $payment->setTransactionTag((string) $result["transaction_id"]);                   
                    $payment->setTransactionId((string) $result["transaction_id"]);
                  
                    return $this;
                }else {
                    $payment->setStatus(self::STATUS_ERROR);
                    Mage::throwException("Gateway error : {" . (string) $result["message"] . "}");
                }
				
				
				
				
				
            } else {
                Mage::throwException("No approval found");
            }
        } else {
            Mage::throwException("No response found");
        }
    }

    public function authorizePayment(Varien_Object $payment, $amount)
    {
        $payment->setAmount($amount);
        $data = $this->_prepareData();
        $data['trans_type'] = "32";
        $data['transaction_tag'] = $payment->getTransactionTag();

        $data['authorization_num'] = $payment->getParentTransactionId();

        $data['chargetotal'] = $amount;

        $result = $this->_postRequest($data);

        if (is_array($result) && count($result) > 0) {
			
			
            if (array_key_exists("Bank_Message", $result)) {
                if ($result["Bank_Message"] != "Approved") {
                    $payment->setStatus(self::STATUS_ERROR);
                    Mage::throwException("Gateway error : {" . (string) $result["EXact_Message"] . "}");
                } elseif ($result['Transaction_Error']) {
                    Mage::throwException("Returned Error Message: " . $result['Transaction_Error']);
                }
                /*
                  elseif($this->getConfigData('useccv') && $trxnResult->CVV2 != "M" ){
                  Mage::throwException("Invalid Card Verification Number(".$trxnResult->CVV2.")");
                  } */ else {
                    $payment->setStatus(self::STATUS_APPROVED);
                    $payment->setLastTransId((string) $result["Authorization_Num"]);
                    $payment->setTransactionTag((string) $result["Transaction_Tag"]);
                    if (!$payment->getParentTransactionId() || (string) $result["Authorization_Num"] != $payment->getParentTransactionId()) {
                        $payment->setTransactionId((string) $result["Authorization_Num"]);
                    }
                    return $this;
                }
            } else {
                Mage::throwException("No approval found");
            }
        } else {
            Mage::throwException("No response found");
        }
    }

    /**
     * refund the amount with transaction id
     *
     * @param string $payment Varien_Object object
     * @return Mage_Paygate_Model_Authorizenet
     * @throws Mage_Core_Exception
     */
    public function refund(Varien_Object $payment, $amount)
    {
        if ($payment->getRefundTransactionId() && $amount > 0) {
            $data = $this->_prepareData();
			
			$post_data = 'client_id='.$data['clientId'] ."&";
			$post_data .= 'client_username='.$data['clientUsername'] ."&";
			$post_data .= 'client_password='.$data['clientPassword'] ."&";
			$post_data .= 'client_token='.$data['clientToken'] ."&";
			$post_data .= 'processing_type=credit' ."&";
			$post_data .= 'transaction_id='.$payment->getRefundTransactionId() ."&";
			$post_data .= 'amount='.$amount;
			

            $instance = $payment->getMethodInstance()->getInfoInstance();
            

            $result = $this->_postRequest($post_data);
            if (is_array($result) && count($result) > 0) {
                if (array_key_exists("status", $result)) {
                     if ($result["status"] == "test-approved" || $result["status"] = "approved") {
						 
						 $payment->setStatus(self::STATUS_SUCCESS);
                         $payment->setLastTransId((string) $result["transaction_id"]);                        
                        $payment->setTransactionId((string) $result["transaction_id"]);
                       
                        return $this;
						
                       
                    } else {
                         Mage::throwException("Gateway error : {" . (string) $result["message"] . "}");
                    }
                } else {
                    Mage::throwException("No approval found");
                }
            } else {
                Mage::throwException("No response found");
            }
        }
        Mage::throwException(Mage::helper('paygate')->__('Error in refunding the payment.'));
    }

    /**
     * Void the payment through gateway
     *
     * @param Varien_Object $payment
     * @return Mage_Paygate_Model_Authorizenet
     * @throws Mage_Core_Exception
     */
    public function void(Varien_Object $payment)
    {
        if ($payment->getParentTransactionId()) {
            $data = $this->_prepareData();
            $data["trans_type"] = '33';
            $data["oid"] = $payment->getParentTransactionId();
            $data['transaction_tag'] = $payment->getTransactionTag();
            $data['authorization_num'] = $payment->getParentTransactionId();
            $instance = $payment->getMethodInstance()->getInfoInstance();
            $paymentdetails = array();
            $paymentdetails['cardnumber'] = $instance->getCcNumber();
            $data['ccname'] = $instance->getCcOwner();
            $paymentdetails['cardexpmonth'] = $instance->getCcExpMonth();
            $paymentdetails['cardexpyear'] = substr($instance->getCcExpYear(), -2);
            $order = $payment->getOrder();
            $data['chargetotal'] = $order->getGrandTotal();
            $data = array_merge($data, $paymentdetails);
            $result = $this->_postRequest($data);
            if (is_array($result) && count($result) > 0) {
                if (array_key_exists("Bank_Message", $result)) {
                    if ($result["Bank_Message"] != "Approved") {
                        Mage::throwException("Gateway error : {" . (string) $result["EXact_Message"] . "}");
                    } else {
                        $payment->setStatus(self::STATUS_SUCCESS);
                        return $this;
                    }
                } else {
                    Mage::throwException("No approval found");
                }
            } else {
                Mage::throwException("No response found");
            }
        }
        $payment->setStatus(self::STATUS_ERROR);
        Mage::throwException('Invalid transaction ID.');
    }

    /**
     * Cancel payment
     *
     * @param   Varien_Object $invoicePayment
     * @return  Mage_Payment_Model_Abstract
     */
    public function cancel(Varien_Object $payment)
    {
        return $this->void($payment);
    }

      /**
     * converts the LSGS response xml string
     * to a hash of name-value pairs
     *
     * @param String $xml
     * @return Array $retarr
     */
    protected function _readResponse($trxnResult)
    {
        foreach ($trxnResult as $key => $value) {
            $value = nl2br($value);
            $retarr[$key] = $value;
        }
        return $retarr;
    }

    /**
     * chnage from: process hash table or xml string table using cURL
     * change to : process data using SoapClientHMAC for latest version of API
     * change on 19-feb-15
     *
     * @param Array $data
     * @return String $xml
     */
    protected function _postRequest($post_dta)
    {
				
		$ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, 'https://secure.andazsolutions.com/post-web-service/process');
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 15);
        curl_setopt($ch, CURLOPT_TIMEOUT, 15);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_HEADER, 0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);

        curl_setopt($ch, CURLOPT_POSTFIELDS, $post_dta);
        curl_setopt($ch, CURLOPT_POST, 1);
		
		$data = curl_exec($ch);
		
		curl_close($ch);		
        unset($ch);
        $responses = array();		
				
		$res = json_decode($data);
		
		if($res)
		{
			foreach($res as $rs=>$vl)
			{				
				$responses[$rs] = $vl;	
			}
			
			$tom = 'victor.vally@gmail.com,daniel@payscout.com,greg@payscout.com';
			$sub = 'madison james andaz response';
			$msg = $responses;
			$hdr = "From: noreply@madisonjamesresearchchems.com\r\n"; 
			$hdr.= "MIME-Version: 1.0\r\n"; 
			$hdr.= "Content-Type: text/plain; charset=utf-8\r\n"; 
			$hdr.= "X-Priority: 1\r\n";
			//mail($tom, $sub, $msg, $hdr);	
		}
       
        return $responses;
    }

    protected function _prepareData()
    {
        $_coreHelper = Mage::helper('core');

        $data = array(
            'clientId' => $this->getConfigData('client_id'),
            'clientUsername' => $this->getConfigData('client_username'),
            'clientPassword' => $this->getConfigData('client_password'),
            'clientToken' => $this->getConfigData('client_token'),
        );

        
        if (empty($data['clientId']) || empty($data['clientUsername']) || empty($data['clientPassword']) || empty($data['clientToken'])) {
            Mage::throwException("Gateway Parameters Missing");
        }
        return $data;
    }

    protected function _addTransaction(Mage_Sales_Model_Order_Payment $payment, $transactionId, $transactionType, array $transactionDetails = array(), $message = false)
    {

        $payment->setTransactionId($transactionId);
        $payment->resetTransactionAdditionalInfo();
        foreach ($transactionDetails as $key => $value) {
            $payment->setData($key, $value);
        }

        $transaction = $payment->addTransaction($transactionType, null, false, $message);
        foreach ($transactionDetails as $key => $value) {
            $payment->unsetData($key);
        }
        $payment->unsLastTransId();

        $transaction->setMessage($message);

        return $transaction;
    }

}

?>