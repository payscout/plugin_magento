<?php
/**
 * Payscout Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 *
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to alex@payscout.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * You can edit or add to this file if you wish to upgrade Magento to newer
 * versions in the future.
 *
 * =================================================================
 *                 MAGENTO EDITION USAGE NOTICE
 * =================================================================
 * This package designed for Magento COMMUNITY edition version 1.5.0.0 to all upper version.
 * Posixtech Ltd. does not guarantee correct work of this extension
 * on any other Magento edition except Magento COMMUNITY edition.
 * Posixtech Ltd. does not provide extension support in case of
 * incorrect edition usage.
 * =================================================================
 *
 * @category   Payscout
 * @package    IncMerchants
 * @copyright  Copyright (c) 2015 Payscout Inc. (http://www.payscout.com)
 * @license    http://www.payscout.com
 */

class Victor_Andaz_Block_Direct_Form_Cc extends Mage_Payment_Block_Form_Cc
{
    /**
     * Set block template
     */
    protected function _construct()
    {
        parent::_construct();
        $this->setTemplate('andaz/form/cc.phtml');
    }

}
